<template>
    <div class="m-empty type01">데이터가 없습니다.</div>
</template>
<style>
.m-empty.type01 {
    padding:60px; margin:40px 0;
    font-size:20px; font-weight:500; text-align: center; color:#999;
    border-top:1px solid #e1e1e1; border-bottom:1px solid #e1e1e1;
}
</style>
<script>
export default {
    computed: {

    },

    methods: {

    }

}
</script>
