<template>
    <div>
        <pop />
        <Nuxt />
    </div>
</template>
<script>

export default {
    head() {
        return {
            link: [
            ],
        }
    },

    components: {

    },

    methods:{

    },

    mounted() {
        // this.$store.commit("init");
    }
}
</script>
